import { initialComplaints } from "@/lib/mock-data/complaints-data";
import {
  CitizenComplaint,
  ComplaintCategory,
  ComplaintNote,
  ComplaintSeverity,
  EscalationRecord,
  HandlerRole,
} from "@/types/complaint";
import { fetchFromBackend } from "./backend-client";

let complaintsState: CitizenComplaint[] = [...initialComplaints];

const delay = (ms = 180) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Chain of Responsibility:
 * Determines appropriate handler tier based on complaint severity.
 */
function resolveInitialHandler(severity: ComplaintSeverity): {
  role: HandlerRole;
  escalationHistory: EscalationRecord[];
} {
  const now = new Date().toISOString();
  if (severity === "LOW") {
    return {
      role: "LOCAL_STAFF",
      escalationHistory: [
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "CITIZEN",
          toRole: "LOCAL_STAFF",
          timestamp: now,
          reason: "Severity LOW: Direct assignment to Local Staff field handler.",
          automated: true,
        },
      ],
    };
  } else if (severity === "MEDIUM") {
    return {
      role: "SUPERVISOR",
      escalationHistory: [
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "CITIZEN",
          toRole: "LOCAL_STAFF",
          timestamp: now,
          reason: "Intake registered at Local Staff gateway.",
          automated: true,
        },
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "LOCAL_STAFF",
          toRole: "SUPERVISOR",
          timestamp: now,
          reason: "Severity MEDIUM: Exceeds Local Staff resolution limit; forwarded along Chain of Responsibility.",
          automated: true,
        },
      ],
    };
  } else if (severity === "HIGH") {
    return {
      role: "CITY_MANAGER",
      escalationHistory: [
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "CITIZEN",
          toRole: "LOCAL_STAFF",
          timestamp: now,
          reason: "Intake registered at Local Staff gateway.",
          automated: true,
        },
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "LOCAL_STAFF",
          toRole: "SUPERVISOR",
          timestamp: now,
          reason: "Severity HIGH: Exceeds Tier 1; forwarded to Supervisor.",
          automated: true,
        },
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "SUPERVISOR",
          toRole: "CITY_MANAGER",
          timestamp: now,
          reason: "Severity HIGH: Escalated to City Manager for departmental intervention.",
          automated: true,
        },
      ],
    };
  } else if (severity === "CRITICAL") {
    return {
      role: "CITY_MANAGER",
      escalationHistory: [
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "CITIZEN",
          toRole: "LOCAL_STAFF",
          timestamp: now,
          reason: "Intake registered at Local Staff gateway.",
          automated: true,
        },
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "LOCAL_STAFF",
          toRole: "SUPERVISOR",
          timestamp: now,
          reason: "Severity CRITICAL: Forwarded along chain immediately.",
          automated: true,
        },
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "SUPERVISOR",
          toRole: "CITY_MANAGER",
          timestamp: now,
          reason: "Severity CRITICAL: Requires executive inter-agency authorization.",
          automated: true,
        },
      ],
    };
  } else {
    // Missing or invalid severity - ValidationTriageHandler NEVER defaults to LOW
    return {
      role: "TRIAGE_OFFICER",
      escalationHistory: [
        {
          id: `esc-${Math.random().toString(36).substring(2, 7)}`,
          fromRole: "CITIZEN",
          toRole: "TRIAGE_OFFICER",
          timestamp: now,
          reason: "Missing/Unverified Severity: Intercepted by ValidationTriageHandler. Routed to Manual Triage.",
          automated: true,
        },
      ],
    };
  }
}

export const ComplaintsService = {
  async getComplaints(): Promise<CitizenComplaint[]> {
    const backendData = await fetchFromBackend<CitizenComplaint[]>("/complaints");
    if (backendData && Array.isArray(backendData)) {
      complaintsState = backendData;
      return backendData;
    }
    throw new Error("Unable to load citizen complaints from MySQL database.");
  },

  async getComplaintById(id: string): Promise<CitizenComplaint | undefined> {
    await delay();
    return complaintsState.find((c) => c.id === id);
  },

  async createComplaint(data: {
    title: string;
    description: string;
    category: ComplaintCategory;
    severity: ComplaintSeverity;
    zoneId: string;
    zoneName: string;
    citizenName: string;
    citizenContact: string;
  }): Promise<CitizenComplaint> {
    try {
      const backendComplaint = await fetchFromBackend<CitizenComplaint>("/complaints", {
        method: "POST",
        body: JSON.stringify(data),
      });
      if (backendComplaint && backendComplaint.id) {
        complaintsState = [backendComplaint, ...complaintsState];
        return backendComplaint;
      }
    } catch {
      // Fallback to local simulation if backend unavailable
    }

    await delay(250);
    const { role, escalationHistory } = resolveInitialHandler(data.severity);
    const now = new Date().toISOString();

    const newComplaint: CitizenComplaint = {
      ...data,
      id: `CMP-${Math.floor(7700 + Math.random() * 2000)}`,
      trackingNumber: `CT-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      currentHandlerRole: role,
      status: role === "LOCAL_STAFF" ? "ASSIGNED" : "ESCALATED",
      submittedAt: now,
      updatedAt: now,
      escalationHistory,
      notes: [
        {
          id: `note-${Math.random().toString(36).substring(2, 7)}`,
          author: "SmartCity Automated Dispatcher",
          role: role,
          text: `Complaint evaluated with ${data.severity} severity and assigned to ${role.replace("_", " ")} handler.`,
          createdAt: now,
        },
      ],
    };

    complaintsState = [newComplaint, ...complaintsState];
    return newComplaint;
  },

  async escalateComplaint(
    complaintId: string,
    reason: string,
    customToRole?: HandlerRole
  ): Promise<CitizenComplaint> {
    const complaint = complaintsState.find((c) => c.id === complaintId);
    let nextRole: HandlerRole;
    if (customToRole) {
      nextRole = customToRole;
    } else {
      if (complaint?.currentHandlerRole === "LOCAL_STAFF") {
        nextRole = "SUPERVISOR";
      } else if (complaint?.currentHandlerRole === "SUPERVISOR") {
        nextRole = "CITY_MANAGER";
      } else {
        nextRole = "CITY_MANAGER";
      }
    }

    try {
      const backendComplaint = await fetchFromBackend<CitizenComplaint>(
        `/complaints/${complaintId}/escalate`,
        {
          method: "PUT",
          body: JSON.stringify({ toRole: nextRole, reason, author: "Operations Officer" }),
        }
      );
      if (backendComplaint) {
        const idx = complaintsState.findIndex((c) => c.id === complaintId);
        if (idx !== -1) complaintsState[idx] = backendComplaint;
        return backendComplaint;
      }
    } catch {
      // Fallback
    }

    await delay(250);
    if (!complaint) throw new Error("Complaint not found");

    const now = new Date().toISOString();
    const escalationRecord: EscalationRecord = {
      id: `esc-${Math.random().toString(36).substring(2, 7)}`,
      fromRole: complaint.currentHandlerRole,
      toRole: nextRole,
      timestamp: now,
      reason,
      automated: false,
      notes: `Escalated along Chain of Responsibility to ${nextRole.replace("_", " ")}.`,
    };

    const newNote: ComplaintNote = {
      id: `note-${Math.random().toString(36).substring(2, 7)}`,
      author: `${complaint.currentHandlerRole.replace("_", " ")} Officer`,
      role: complaint.currentHandlerRole,
      text: `Escalation dispatched to ${nextRole.replace("_", " ")}. Reason: ${reason}`,
      createdAt: now,
    };

    complaint.currentHandlerRole = nextRole;
    complaint.status = "ESCALATED";
    complaint.updatedAt = now;
    complaint.escalationHistory.push(escalationRecord);
    complaint.notes.push(newNote);

    return { ...complaint };
  },

  async addNote(complaintId: string, text: string, author: string, role: HandlerRole): Promise<CitizenComplaint> {
    await delay(180);
    const complaint = complaintsState.find((c) => c.id === complaintId);
    if (!complaint) throw new Error("Complaint not found");

    const note: ComplaintNote = {
      id: `note-${Math.random().toString(36).substring(2, 7)}`,
      author,
      role,
      text,
      createdAt: new Date().toISOString(),
    };

    complaint.notes.push(note);
    complaint.updatedAt = new Date().toISOString();
    return { ...complaint };
  },

  async resolveComplaint(complaintId: string, resolutionSummary: string): Promise<CitizenComplaint> {
    try {
      const backendComplaint = await fetchFromBackend<CitizenComplaint>(
        `/complaints/${complaintId}/resolve`,
        {
          method: "PUT",
          body: JSON.stringify({ resolutionSummary }),
        }
      );
      if (backendComplaint) {
        const idx = complaintsState.findIndex((c) => c.id === complaintId);
        if (idx !== -1) complaintsState[idx] = backendComplaint;
        return backendComplaint;
      }
    } catch {
      // Fallback to local state if backend is offline
    }

    await delay(250);
    const complaint = complaintsState.find((c) => c.id === complaintId);
    if (!complaint) throw new Error("Complaint not found");

    const now = new Date().toISOString();
    complaint.status = "RESOLVED";
    complaint.resolutionSummary = resolutionSummary;
    complaint.resolvedAt = now;
    complaint.updatedAt = now;

    complaint.notes.push({
      id: `note-${Math.random().toString(36).substring(2, 7)}`,
      author: `${complaint.currentHandlerRole.replace("_", " ")} Handler`,
      role: complaint.currentHandlerRole,
      text: `Ticket resolved: ${resolutionSummary}`,
      createdAt: now,
    });

    return { ...complaint };
  },
};

